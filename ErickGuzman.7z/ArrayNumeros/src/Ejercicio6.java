public class Ejercicio6 {
	public static int fibo(int n) {
	    if (n <= 1) {
	        return n;
	    } else {
	        int a = 0, b = 1, temp;
	        for (int i = 2; i <= n; i++) {
	            temp = a + b;
	            a = b;
	            b = temp;
	        }
	        return b;
	    }
	}

	public static void main(String[] args) {
	    // Declaracion de la tabla 20 posiciones
	    int tabla[] = new int[20];

	    // Imprimir la secuencia de Fibonacci hasta el término especificado
	    System.out.println("Secuencia de Fibonacci hasta el término " + tabla.length + ":");
	    for (int i = 0; i < tabla.length; i++) {
	        System.out.print(fibo(i) + " ");
	    }
	}
}
    
	    