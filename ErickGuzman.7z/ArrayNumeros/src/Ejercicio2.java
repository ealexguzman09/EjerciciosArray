
public class Ejercicio2 {

	public static void main(String[] args) {
		/*En un array de 10 valores enteros, ¿es mayor la suma de la primera mitad o la suma de la segunda mitad?*/
		
		//Declaramos variables
		int tabla[]= {3,6,2,77,3,10,23,14,21,10};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
		int suma1 = 0;
		int suma2 = 0;
		int sumat = 0;
		
		// Bucle for que recorre el array "tabla" y suma todos sus elementos
		for(int i=0; i <tabla.length; i++)
			suma1 = suma1 + tabla[i];
		
			// Bucle for que recorre la primera mitad del array "tabla" y suma sus elementos
			for(int i=0; i <tabla.length/2; i++)
				sumat = sumat + tabla[i];
			
			// Calcula la suma de la segunda mitad restando la suma de la primera mitad de la suma total
				suma2 = suma1 - sumat;

				// Muestra las sumas
				System.out.println("La suma de numeros total es: " + suma1 );
				System.out.println("La suma de la primera mitad es: " + sumat );
				System.out.println("La suma de la segunda mitad es: " + suma2 );
				System.out.println();
				
				// Compara las sumas de la primera mitad y la segunda mitad e imprime el resultado
					if(sumat>suma2)
						System.out.println("La primera mitad de numeros es mayor.");
						else
							System.out.println("La segunda mitad de numeros es mayor.");

			
			}
	
	}