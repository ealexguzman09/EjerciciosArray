
public class Ejercicio10 {
	static int divisible(int[] array) {
        int divi = 0;

        for (int i = 0; i < array.length; i++) {
            if (array[i] % 7 == 0) {
                System.out.println(array[i]);
                divi++;
            }
        }

        return divi;
    }

    public static void main(String[] args) {
        // Declarar tabla y variables
        int[] tabla = {3, 6, 2, 77, 3, 10, 23, 14};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
        int resultado;

        // Llamar al método y mostrar el resultado
        System.out.println("Los numeros divisibles para 7 son:");
        resultado = divisible(tabla);
        System.out.println("Cantidad de numeros divisibles por 7: " + resultado);
    }
}
	