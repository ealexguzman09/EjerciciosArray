
public class Ejercicio3 {

	public static void main(String[] args) {
		// Declaracion de variables
		int tabla[] = {3, 6, 2, 77, 3, 10, 23, 14, 21, 10};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
		int iguales = tabla.length;
		boolean diferentes;

		// Suponemos inicialmente que todos los elementos son diferentes
		diferentes = true;

		// Bucle anidado para comparar cada par de elementos y verificar si son iguales
		for (int i = 0; i < iguales - 1; i++) {
		    for (int j = i + 1; j < iguales; j++) {
		        if (tabla[i] == tabla[j]) {
		            diferentes = false; // Al menos un par de elementos son iguales
		            break;
		        }
		    }
		    if (!diferentes) {
		        break;
		    }
		}

		// Imprime el resultado de la comparación
		if (diferentes) {
		    System.out.println("Todos los elementos son diferentes.");
		} else {
		    System.out.println("Al menos un par de elementos son iguales.");
		}
	}
}