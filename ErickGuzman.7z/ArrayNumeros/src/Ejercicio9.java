public class Ejercicio9 {

	static boolean seRepite(int t[], int numero, int cantidad) {
	    for (int i = 0; i < cantidad; i++)
	        if (t[i] == numero)
	            return true;

	    return false;
	}

	public static void main(String[] args) {
	    // Declarar "tabla" con 8 posiciones
	    int tabla[] = new int[8];

	    // Calcular 8 posiciones diferentes
	    for (int i = 0; i < tabla.length; i++) {
	        int aleatorio;

	        // Generar un número aleatorio y asegurarse de que no se repita en las posiciones anteriores
	        aleatorio = (int) Math.floor(Math.random() * 40);
	        while (seRepite(tabla, aleatorio, i));

	        tabla[i] = aleatorio;
	    }

	    // Visualizar tabla
	    for (int i = 0; i < tabla.length; i++)
	        System.out.println(i + " - " + tabla[i]);
	}
}
	
