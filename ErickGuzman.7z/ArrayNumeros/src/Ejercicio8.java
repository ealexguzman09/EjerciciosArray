
public class Ejercicio8 {
	static boolean esSimetrica(int[] tabla) {
	    int longitud = tabla.length;

	    // Verificar los elementos correspondientes en ambas direcciones
	    for (int i = 0; i < longitud / 2; i++) {
	        if (tabla[i] != tabla[longitud - 1 - i]) {
	            return false;
	        }
	    }
	    return true;
	}

	public static void main(String[] args) {
	    // Declarar la tabla
		//Eliminar las plecas(/) de la tabla cual desea probar
		//int[] tabla = {3, 6, 2, 77, 3, 10, 23, 14};//Tabla original
	    //int[] tabla = {1, 2, 2, 2, 2, 2, 2, 1};	//Tabla de prueba

	    // Verificar si es la misma secuencia al leer de izquierda a derecha y de derecha a izquierda
	    if (esSimetrica(tabla)) {
	        System.out.println("La secuencia es simétrica.");
	    } else {
	        System.out.println("La secuencia no es simétrica.");
	    }
	}
}

 
