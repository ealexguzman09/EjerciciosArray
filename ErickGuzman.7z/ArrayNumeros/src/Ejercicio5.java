
public class Ejercicio5 {
    static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

    public static void main(String[] args) {
        int[] tabla = new int[10];

        // Calcular y almacenar el factorial en cada posición del array
        for (int i = 0; i < tabla.length; i++) {
            tabla[i] = factorial(i);
        }

        // Imprimir el array resultante
        System.out.println("Factoriales almacenados en el array:");
        for (int i = 0; i < tabla.length; i++) {
            System.out.println("Posición " + i + ": " + tabla[i]);
        }
    }
}