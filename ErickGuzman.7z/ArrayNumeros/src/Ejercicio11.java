public class Ejercicio11 {
    // Verificar si un número es primo
    static boolean esPrimo(int numero) {
        if (numero < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
    	//Declaracion de tabla y variables
        int[] tabla = {3, 6, 2, 77, 3, 10, 23, 14};
        int cantidadPrimos = 0;

        // Verificar si todos los números en la tabla son primos
        boolean todosPrimos = true;
        for (int numero : tabla) {
            if (esPrimo(numero)) {
                cantidadPrimos++;
            } else {
                todosPrimos = false;
                break;
            }
        }

        // Imprimir el resultado
        if (todosPrimos) {
            System.out.println("Todos los números en la tabla son primos.");
        } else {
            System.out.println("No todos los números en la tabla son primos.");
        }

        // Imprimir la cantidad de números primos encontrados
        System.out.println("Cantidad de números primos en el array: " + cantidadPrimos);
    }
}