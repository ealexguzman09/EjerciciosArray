
public class Ejercicio1 {
	
	public static void main(String[] args) {
		
		int tabla[]= {3,6,2,77,3,10,23,14};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
		int contador=0;
		
		/*¿Cuantos valores de 3 hay en el array?*/
		for(int i=0;i<tabla.length;i++) {		
			if(tabla[i]==3)
				contador++;
				
		}
			
		System.out.println("Hay: "+ contador + " valores '3' en el array.");
		
	}

}
