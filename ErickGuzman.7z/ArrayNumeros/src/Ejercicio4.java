
public class Ejercicio4 {
    static void imprimirTabla(int[] tabla) {
        for (int elemento : tabla) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }

    // Método para rotar la tabla a la derecha
    static void rotarDerecha(int[] tabla) {
        if (tabla.length <= 1) {
            return;
        }
        //Guardamos el ultimo numero de la tabla
        int ultimo = tabla[tabla.length - 1];

        // Desplazar los elementos a la derecha
        for (int i = tabla.length - 1; i > 0; i--) {
            tabla[i] = tabla[i - 1];
        }
        //Insertamos el ultimo numero en la posicion 0
        tabla[0] = ultimo;
    }

		public static void main(String[] args) {
			// Declararcion de variables
	        int[] tabla = {3, 6, 2, 77, 3, 10, 23, 14, 21, 10};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
	        System.out.println("Tabla inicial:");
	        imprimirTabla(tabla);
	        rotarDerecha(tabla);

	        //Tabla final
	        System.out.println("Tabla final:");
	        imprimirTabla(tabla);
	    }
	}



