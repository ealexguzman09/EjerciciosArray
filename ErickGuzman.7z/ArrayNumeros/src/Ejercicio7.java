 
public class Ejercicio7 {

	public static void main(String[] args) {
	    // Declaración de variables
	    int tabla[] = {3, 6, 2, 77, 3, 10, 23, 14};
	    int par = 0;
	    int impar = 0;

	    // Contar la cantidad de números pares e impares en el array
	    for (int i = 0; i < tabla.length; i++) {
	        if (tabla[i] % 2 == 0)
	            par++;
	        else
	            impar++;
	    }

	    // Determinar e imprimir si hay más números pares, impares o igual cantidad de ambos
	    if (par > impar) {
	        System.out.println("Hay más números pares que impares.");
	        System.out.println("Cantidad de pares: " + par);
	        System.out.println("Cantidad de impares: " + impar);
	    } else if (impar > par) {
	        System.out.println("Hay más números impares que pares.");
	        System.out.println("Cantidad de pares: " + par);
	        System.out.println("Cantidad de impares: " + impar);
	    } else {
	        System.out.println("Hay la misma cantidad de pares que impares.");
	        System.out.println("Cantidad de pares: " + par);
	    }
	}
}