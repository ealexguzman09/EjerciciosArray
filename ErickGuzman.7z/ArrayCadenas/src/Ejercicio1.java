
public class Ejercicio1 {

	public static void main(String[] args) {
	    // Declarar las tablas
	    String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
	    int[] tabla = new int[cadenas.length];

	    // Calcular las longitudes
	    for (int i = 0; i < cadenas.length; i++) {
	        tabla[i] = cadenas[i].length();
	    }

	    // Mostrar las longitudes de las cadenas
	    System.out.println("Longitudes de las cadenas:");
	    for (int i = 0; i < tabla.length; i++) {
	        System.out.println("Longitud en posición " + i + ": " + tabla[i]);
	    }
	}
}
