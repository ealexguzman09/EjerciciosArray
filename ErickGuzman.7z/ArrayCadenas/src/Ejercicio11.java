
public class Ejercicio11 {
	public static void main(String[] args) {
		//Declarando la tabla y las variables.
		String[] nombres = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.
        int maxVocales = 0;
        String nombreMaxVocales = "";
        int posMaxVocales = -1;

        for (int i = 0; i < nombres.length; i++) {
            int contadorVocales = 0;

            for (int j = 0; j < nombres[i].length(); j++) {
                char caracter = Character.toLowerCase(nombres[i].charAt(j));

                if (caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u') {
                    contadorVocales++;
                }
            }

            //Verificar Máximo de Vocales
            if (contadorVocales > maxVocales) {
                maxVocales = contadorVocales;
                nombreMaxVocales = nombres[i];
                posMaxVocales = i;
            }
        }

        //Imprimir el Nombre con más Vocales
        System.out.println("El nombre con más vocales es: " + nombreMaxVocales + " con " + maxVocales + " vocales.");
        System.out.println("Se encuentra en la posición: " + posMaxVocales);
    }
}
