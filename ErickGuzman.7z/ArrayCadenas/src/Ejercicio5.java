
	public class Ejercicio5 {

	    public static void main(String[] args) {
	        // declaro la tabla
	        String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};//Para comprobar si funciona puede agregar mas nombres a la tabla si asi se desea

	        for (int i = 0; i < cadenas.length; i++) {
	            // Convertir a Mayúsculas
	            String cadenaMayusculas = cadenas[i].toUpperCase();

	            // Mostrar cadenas en mayúsculas
	            System.out.println(cadenaMayusculas);
	        }
	    }
	}
