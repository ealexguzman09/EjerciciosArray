public class Ejercicio3 {

    // Método para contar las letras mayúsculas en una cadena
    private static int contarMayus(String cadena) {
        int contador = 0;

        for (int j = 0; j < cadena.length(); j++) {
            char caracter = cadena.charAt(j);
            if (caracter >= 'A' && caracter <= 'Z') {
                contador++;
            }
        }

        return contador;
    }

    public static void main(String[] args) {
    	//Para que puedas comprobarlo mejor cambia las mayúsculas y minúsculas de la siguiente tabla de datos a tu disposicion.
    			String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};
    			//Ejemplo
    			//String[] cadenas = {"SUE", "CharloTTe", "ANna", "MIKe", "WilLIaM", "ED"};

        // Imprimir el número de letras mayúsculas en cada cadena del array
        for (int i = 0; i < cadenas.length; i++) {
            int contador = contarMayus(cadenas[i]);
            System.out.println("En la posición " + i + " hay " + contador + " letras mayúsculas.");
        }
    }
}

