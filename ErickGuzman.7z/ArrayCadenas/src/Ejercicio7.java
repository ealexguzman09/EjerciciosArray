
public class Ejercicio7 {

    // Método que verifica si una cadena contiene una subcadena de forma insensible a mayúsculas/minúsculas
    public static boolean contieneSubcadena(String cadena, String subcadena) {
        return cadena.toLowerCase().contains(subcadena.toLowerCase());
    }

    public static void main(String[] args) {
        // Declarando tabla y variable
        String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};
        int contadorSubcadena = 0;

 
        for (int i = 0; i < cadenas.length; i++) {
            //Verificar Subcadena
            if (contieneSubcadena(cadenas[i], "zar")) {
                contadorSubcadena++;

                //Imprimir Cadena que Contiene la Subcadena 'zar'
                System.out.println(cadenas[i] + " contiene la subcadena 'zar'.");
            }
        }

        //Imprimir Final
        System.out.println("En total, hay " + contadorSubcadena + " cadenas que contienen la subcadena 'zar'.");
    }
}
