
public class Ejercicio2 {

    public static void main(String[] args) {
        // Declarar la tabla
        String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};//Si desea comprobar si funciona cambiar los valores de la tabla a gusto propio.

        // Encontrar la cadena alfabéticamente primera y su posición
        String cadena1 = cadenas[0];
        int primera = 0;

        for (int i = 1; i < cadenas.length; i++) {
            if (cadenas[i].compareTo(cadena1) < 0) {
                cadena1 = cadenas[i];
                primera = i;
            }
        }

        // Imprimir la cadena alfabéticamente primera y su posición
        System.out.println("La cadena alfabéticamente primera es: " + cadena1 + ", en posición " + primera + ".");
    }
}
