public class Ejercicio4 {
	public static boolean masMayus(String cadena) {
	int contadorMayus = 0;
    int contadorMinus = 0;

    for (int j = 0; j < cadena.length(); j++) {
        char caracter = cadena.charAt(j);
        if (Character.isUpperCase(caracter)) {
            contadorMayus++;
        } 
        else if 
        	(Character.isLowerCase(caracter)) {
            contadorMinus++;
        }
    }

    return contadorMayus > contadorMinus;
	}

	public static void main(String[] args) {
		//String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};
		String[] cadenas = {"SUE", "CharloTTe", "ANna", "MIKe", "WilLIaM", "ED"};

        int contadorCadenas = 0;

        for (int i = 0; i < cadenas.length; i++) {
            if (masMayus(cadenas[i])) {
                contadorCadenas++;
            }
        }

        System.out.println("En total, hay " + contadorCadenas + " cadenas con más letras mayúsculas que minúsculas.");
    }
}

//OJO
//para este ejercicio me guie completamente de internet ya que no pude hacerlo por mi cuenta
//si no se toma en cuenta para la evaluacion lo entenderé.Solo me gustaria saber si esta correcto asi o hay alguna manera mas facil de hacerlo.