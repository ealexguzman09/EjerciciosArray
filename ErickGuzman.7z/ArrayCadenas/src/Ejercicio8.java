
public class Ejercicio8 {
	 public static void main(String[] args) {
	        //Declarando tabla y variable
	        String[] nombres = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};
	        int numNombre = 0;

	        //Verificar Nombres que Comienzan con 'A' o 'a'
	        for(int i = 0; i < nombres.length; i++) {
	            if(nombres[i].charAt(0) == 'A' || nombres[i].charAt(0) == 'a') {
	                numNombre++;
	                
	                //Imprimir Nombres que Comienzan con 'A' o 'a'
	                System.out.println(nombres[i] + " comienza por 'A'.");
	            }
	        }
	        
	        // Verificar Cantidad de Nombres
	        if (numNombre >= 2)
	            System.out.println("Hay " + numNombre + " nombres que inician por la letra 'A'.");
	        else
	            System.out.println("Hay " + numNombre + " nombre que inicia por la letra 'A'.");
	    }
	}
