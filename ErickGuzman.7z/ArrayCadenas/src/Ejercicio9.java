
public class Ejercicio9 {
		public static void main(String[] args) {
			//Declarando la tabla y las variables
			String[] nombres = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};//Para comprobar si funciona puede agregar mas nombres a la tabla si asi se desea       
	        int max = 0;
	        int posmax = 0;

	        for(int i = 0; i < nombres.length; i++) {
	            //Verificar Longitud Máxima
	            if(nombres[i].length() > max) {
	                max = nombres[i].length();
	                posmax = i;
	            }
	        }

	        //Imprimir el Nombre más Largo y su Posición
	        System.out.println("El nombre más largo es: " + nombres[posmax] + " que tiene " + max + " letras.");
	        System.out.println("Se encuentra en la posición: " + posmax);
	    }
	}
